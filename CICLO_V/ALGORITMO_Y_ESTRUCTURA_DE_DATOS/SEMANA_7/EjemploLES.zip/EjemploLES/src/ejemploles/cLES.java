/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemploles;

/**
 *
 * @author c00210
 */
public class cLES {
    private cNodo inicio, nuevo, p, q;
    
    public void insertaxInicio(int valor){
        nuevo = new cNodo(valor);
        if(inicio == null){
            inicio = nuevo;
        }
        else{
            nuevo.setSgte(inicio);
            inicio = nuevo;
        }
    }
    public void insertaxFinal(int valor){
        nuevo = new cNodo(valor);
        if(inicio == null){
            inicio = nuevo;
        }
        else{
            p = inicio;
            while(p.getSgte() != null){
                p = p.getSgte();
            }
            p.setSgte(nuevo);
        }
    }
    public String recorreLE(){
        String cadena="";
        if(inicio != null){
            p= inicio;
            while(p != null){
                cadena = cadena + p.getDato()+" - ";
                p = p.getSgte();
            }
        }
        return cadena;
    }
}
